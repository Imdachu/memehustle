module.exports = {
  content: [
    './index.html',
    './src/**/*.{js,jsx,ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        'neon-pink': '#ff00ff',
        'neon-blue': '#00ffff',
        'neon-green': '#39ff14',
      },
      backgroundImage: {
        'neon-gradient': 'linear-gradient(to right, #ff00ff, #00ffff)',
      },
    },
  },
  plugins: [],
};
