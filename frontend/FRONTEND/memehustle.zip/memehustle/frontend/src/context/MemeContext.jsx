import React, { createContext, useContext, useEffect, useState } from 'react';
import io from 'socket.io-client';
import axios from 'axios';
import { debug } from '../utils/debug';

const API_URL = 'http://localhost:5000';

const MemeContext = createContext();

export const useMemeContext = () => {
  const context = useContext(MemeContext);
  if (!context) {
    debug.error('useMemeContext must be used within a MemeProvider');
    throw new Error('useMemeContext must be used within a MemeProvider');
  }
  return context;
};

export const MemeProvider = ({ children }) => {
  const [memes, setMemes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [socket, setSocket] = useState(null);

  useEffect(() => {
    debug.info('Initializing socket connection');
    const newSocket = io(API_URL, {
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
      withCredentials: true,
      transports: ['websocket', 'polling']
    });

    newSocket.on('connect', () => {
      debug.socket('connected', { id: newSocket.id });
      setSocket(newSocket);
    });

    newSocket.on('connect_error', (err) => {
      debug.error('Socket connection error', err);
      setError('Failed to connect to server');
    });

    newSocket.on('disconnect', (reason) => {
      debug.warn('Socket disconnected', { reason });
      setSocket(null);
    });

    return () => {
      debug.info('Cleaning up socket connection');
      if (newSocket) {
        newSocket.close();
      }
    };
  }, []);

  useEffect(() => {
    if (!socket) {
      debug.warn('Socket not initialized, skipping event handlers setup');
      return;
    }

    debug.info('Setting up socket event handlers');
    const handlers = {
      'new-meme': (meme) => {
        debug.socket('new-meme received', meme);
        setMemes(prev => {
          if (prev.some(m => m.id === meme.id)) return prev;
          return [meme, ...prev];
        });
      },
      'vote': ({ id, upvotes }) => {
        debug.socket('vote received', { id, upvotes });
        setMemes(prev => prev.map(m => m.id === id ? { ...m, upvotes } : m));
      },
      'bid': (bid) => {
        debug.socket('bid received', bid);
        setMemes(prev => prev.map(m => 
          m.id === bid.id ? { ...m, highestBid: bid.credits, highestBidder: bid.user_id } : m
        ));
      },
      'caption': (updated) => {
        debug.socket('caption update received', updated);
        setMemes(prev => prev.map(m => m.id === updated.id ? updated : m));
      },
      'delete-meme': ({ id }) => {
        debug.socket('delete-meme received', id);
        setMemes(prev => prev.filter(m => m.id !== id));
      }
    };

    Object.entries(handlers).forEach(([event, handler]) => {
      debug.log(`Registering handler for ${event}`);
      socket.on(event, handler);
    });

    return () => {
      debug.info('Cleaning up socket event handlers');
      Object.entries(handlers).forEach(([event, handler]) => {
        socket.off(event, handler);
      });
    };
  }, [socket]);

  const fetchMemes = async () => {
    debug.api('GET', '/memes');
    try {
      setLoading(true);
      const response = await axios.get(`${API_URL}/memes`);
      debug.log('Memes fetched successfully', { count: response.data.length });
      setMemes(response.data);
      setError(null);
    } catch (err) {
      debug.error('Failed to fetch memes', err);
      setError('Failed to fetch memes');
    } finally {
      setLoading(false);
    }
  };

  const createMeme = async (memeData) => {
    debug.api('POST', '/memes', memeData);
    try {
      const transformedData = {
        image_url: memeData.imageUrl,
        uploaded_by: memeData.uploadedBy,
        title: memeData.title,
        tags: memeData.tags
      };
      const response = await axios.post(`${API_URL}/memes`, transformedData);
      debug.log('Meme created successfully', response.data);
      return response.data;
    } catch (err) {
      debug.error('Failed to create meme', err);
      setError('Failed to create meme');
      throw err;
    }
  };

  const voteMeme = async (id, type) => {
    debug.api('POST', `/memes/${id}/vote`, { type });
    try {
      const response = await axios.post(`${API_URL}/memes/${id}/vote`, { type });
      debug.log('Vote recorded successfully', response.data);
      return response.data;
    } catch (err) {
      debug.error('Failed to vote on meme', err);
      setError('Failed to vote on meme');
      throw err;
    }
  };

  const bidOnMeme = async (id, bidData) => {
    debug.api('POST', `/memes/${id}/bid`, bidData);
    try {
      const response = await axios.post(`${API_URL}/memes/${id}/bid`, bidData);
      debug.log('Bid placed successfully', response.data);
      return response.data;
    } catch (err) {
      debug.error('Failed to place bid', err);
      setError('Failed to place bid');
      throw err;
    }
  };

  const deleteMeme = async (id) => {
    debug.api('DELETE', `/memes/${id}`);
    try {
      await axios.delete(`${API_URL}/memes/${id}`);
      setMemes(prev => prev.filter(m => m.id !== id));
    } catch (err) {
      debug.error('Failed to delete meme', err);
      setError('Failed to delete meme');
      throw err;
    }
  };

  useEffect(() => {
    debug.info('Initial meme fetch triggered');
    fetchMemes();
  }, []);

  const value = {
    memes,
    loading,
    error,
    createMeme,
    voteMeme,
    bidOnMeme,
    fetchMemes,
    deleteMeme
  };

  return (
    <MemeContext.Provider value={value}>
      {children}
    </MemeContext.Provider>
  );
}; 