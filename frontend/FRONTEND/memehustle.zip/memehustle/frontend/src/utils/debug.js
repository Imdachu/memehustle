const DEBUG = true;

export const debug = {
  log: (message, data = null) => {
    if (DEBUG) {
      console.log(`🔍 [DEBUG] ${message}`, data || '');
    }
  },
  error: (message, error = null) => {
    if (DEBUG) {
      console.error(`❌ [ERROR] ${message}`, error || '');
    }
  },
  warn: (message, data = null) => {
    if (DEBUG) {
      console.warn(`⚠️ [WARN] ${message}`, data || '');
    }
  },
  info: (message, data = null) => {
    if (DEBUG) {
      console.info(`ℹ️ [INFO] ${message}`, data || '');
    }
  },
  socket: (event, data = null) => {
    if (DEBUG) {
      console.log(`🔌 [SOCKET] ${event}`, data || '');
    }
  },
  api: (method, endpoint, data = null) => {
    if (DEBUG) {
      console.log(`🌐 [API] ${method} ${endpoint}`, data || '');
    }
  }
}; 