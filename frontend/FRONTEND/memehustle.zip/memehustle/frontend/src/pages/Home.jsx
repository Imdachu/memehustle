import React from 'react';
import MemeGallery from '../components/MemeGallery';

const Home = () => (
  <div className="flex flex-col items-center justify-center min-h-screen text-center w-full">
    <h1 className="text-5xl font-extrabold text-pink-500 drop-shadow-neon mb-4">MemeHustle Home</h1>
    <p className="text-lg text-blue-300 max-w-xl mb-8">Welcome to the MemeHustle cyberpunk meme marketplace. Browse the latest memes or dive into the leaderboard!</p>
    <div className="w-full max-w-3xl">
      <MemeGallery />
    </div>
  </div>
);

export default Home; 