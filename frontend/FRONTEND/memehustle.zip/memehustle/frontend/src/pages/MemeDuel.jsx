import React from 'react';
import MemeDuelModal from '../components/MemeDuelModal';

const MemeDuel = () => (
  <div className="flex flex-col items-center justify-center min-h-screen text-center w-full">
    <h1 className="text-5xl font-extrabold text-cyan-400 drop-shadow-neon mb-4">Meme Duel</h1>
    <p className="text-lg text-blue-300 max-w-xl mb-8">Witness epic meme battles and vote for your champion!</p>
    <div className="w-full max-w-3xl">
      <MemeDuelModal open={true} onClose={() => {}} isPageMode={true} />
    </div>
  </div>
);

export default MemeDuel; 