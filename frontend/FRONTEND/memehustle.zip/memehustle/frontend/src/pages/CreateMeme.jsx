import React from 'react';
import MemeForm from '../components/MemeForm';

const CreateMeme = () => (
  <div className="flex flex-col items-center justify-center min-h-screen text-center w-full">
    <h1 className="text-5xl font-extrabold text-green-400 drop-shadow-neon mb-4">Create a Meme</h1>
    <p className="text-lg text-blue-300 max-w-xl mb-8">Submit your dankest meme to the MemeHustle marketplace!</p>
    <div className="w-full max-w-2xl">
      <MemeForm />
    </div>
  </div>
);

export default CreateMeme; 