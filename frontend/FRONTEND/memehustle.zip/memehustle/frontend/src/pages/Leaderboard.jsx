import React from 'react';
import MemeGallery from '../components/MemeGallery';

const Leaderboard = () => (
  <div className="flex flex-col items-center justify-center min-h-screen text-center w-full">
    <h1 className="text-5xl font-extrabold text-yellow-300 drop-shadow-neon mb-4">Leaderboard</h1>
    <p className="text-lg text-blue-300 max-w-xl mb-8">See the top upvoted memes in the MemeHustle universe!</p>
    <div className="w-full max-w-3xl">
      <MemeGallery sortBy="votes" />
    </div>
  </div>
);

export default Leaderboard; 