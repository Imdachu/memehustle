import { useMemeContext } from '../context/MemeContext';
import MemeCard from './MemeCard';

const cyberpunkFont = {
  fontFamily: '"Share Tech Mono", "Fira Mono", monospace',
  color: '#ff00cc',
  textShadow: '0 0 8px #ff00cc, 0 0 16px #00fff7',
  letterSpacing: '1px',
};

const MemeGallery = () => {
  const { memes, loading, error } = useMemeContext();

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-pink-500 shadow-neon-pink"></div>
        <span className="ml-4 text-pink-400 text-lg" style={cyberpunkFont}>Loading Memes...</span>
        <style>{`.shadow-neon-pink { box-shadow: 0 0 24px #ff00cc, 0 0 8px #00fff7; }`}</style>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center p-4">
        <p className="text-red-500" style={cyberpunkFont}>{error}</p>
        <button 
          onClick={() => window.location.reload()}
          className="mt-4 px-4 py-2 bg-pink-500 text-black rounded hover:bg-pink-700 shadow-cyber-glow"
          style={{ boxShadow: '0 0 10px #ff00cc, 0 0 20px #00fff7' }}
        >
          Retry
        </button>
        <style>{`.shadow-cyber-glow { box-shadow: 0 0 10px #ff00cc, 0 0 20px #00fff7; }`}</style>
      </div>
    );
  }

  // Ensure memes is an array
  const memeArray = Array.isArray(memes) ? memes : [];

  if (!memeArray.length) {
    return (
      <div className="text-center p-4">
        <p className="text-pink-400" style={cyberpunkFont}>No memes yet. Be the first to create one!</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-2 bg-gradient-to-br from-black via-gray-900 to-blue-950 rounded-xl shadow-cyber-glitch" style={{ minHeight: '60vh' }}>
      {memeArray.map((meme) => (
        <MemeCard key={meme.id} meme={meme} />
      ))}
      <style>{`.shadow-cyber-glitch { box-shadow: 0 0 32px #00fff7, 0 0 16px #ff00cc, 0 0 8px #a020f0; }`}</style>
    </div>
  );
};

export default MemeGallery;
