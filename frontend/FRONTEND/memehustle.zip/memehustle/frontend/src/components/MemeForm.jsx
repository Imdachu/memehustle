import { useState } from 'react';
import { useMemeContext } from '../context/MemeContext';

const MemeForm = () => {
  const [imageUrl, setImageUrl] = useState('');
  const [title, setTitle] = useState('');
  const [tags, setTags] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const { createMeme } = useMemeContext();

  const DEFAULT_IMAGE_URL = 'https://i.imgur.com/2DhmtJ4.jpg'; // Stonks meme or any placeholder

  const validateImageUrl = (url) => {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    if (!title.trim()) {
      setError('Please enter a title');
      return;
    }

    // Use default image if none provided
    const finalImageUrl = imageUrl.trim() ? imageUrl : DEFAULT_IMAGE_URL;

    if (!validateImageUrl(finalImageUrl)) {
      setError('Please enter a valid URL');
      return;
    }

    try {
      setIsSubmitting(true);
      await createMeme({ 
        imageUrl: finalImageUrl, 
        title,
        tags, // comma-separated string
        uploadedBy: 'cyberpunk420', // TODO: Replace with actual user authentication
        timestamp: new Date().toISOString()
      });
      setImageUrl('');
      setTitle('');
      setTags('');
    } catch (err) {
      setError('Failed to create meme. Please try again.');
      console.error('Create meme error:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const cyberpunkFont = {
    fontFamily: '"Share Tech Mono", "Fira Mono", monospace',
    color: '#ff00cc',
    textShadow: '0 0 8px #ff00cc, 0 0 16px #00fff7',
    letterSpacing: '1px',
  };

  return (
    <div className="mb-8 flex justify-center">
      <form onSubmit={handleSubmit} className="space-y-4 w-full max-w-md bg-black bg-opacity-80 p-6 rounded-xl border-2 border-pink-500 shadow-cyber-glitch" style={cyberpunkFont}>
        <div>
          <input
            type="text"
            placeholder="Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full p-2 mb-2 bg-black text-pink-400 border border-pink-500 rounded focus:ring-2 focus:ring-blue-500"
            disabled={isSubmitting}
            style={{ boxShadow: '0 0 8px #ff00cc' }}
          />
          <input
            type="text"
            placeholder="Image URL"
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            className="w-full p-2 mb-2 bg-black text-pink-400 border border-pink-500 rounded focus:ring-2 focus:ring-blue-500"
            disabled={isSubmitting}
            style={{ boxShadow: '0 0 8px #00fff7' }}
          />
          <input
            type="text"
            placeholder="Tags (comma separated)"
            value={tags}
            onChange={(e) => setTags(e.target.value)}
            className="w-full p-2 bg-black text-purple-400 border border-purple-500 rounded focus:ring-2 focus:ring-pink-500"
            disabled={isSubmitting}
            style={{ boxShadow: '0 0 8px #a020f0' }}
          />
          {error && (
            <p className="mt-1 text-red-500 text-sm" style={{ textShadow: '0 0 6px #ff00cc' }}>{error}</p>
          )}
        </div>
        <button
          type="submit"
          className={`px-4 py-2 bg-pink-500 hover:bg-pink-700 text-black font-bold rounded shadow-cyber-glow neon-btn
            ${isSubmitting ? 'opacity-50 cursor-not-allowed' : ''}`}
          disabled={isSubmitting}
          style={{ boxShadow: '0 0 10px #ff00cc, 0 0 20px #00fff7' }}
        >
          {isSubmitting ? 'Creating...' : 'Generate Meme'}
        </button>
        <style>{`
          .shadow-cyber-glow { box-shadow: 0 0 10px #ff00cc, 0 0 20px #00fff7; }
          .shadow-cyber-glitch { box-shadow: 0 0 32px #00fff7, 0 0 16px #ff00cc, 0 0 8px #a020f0; }
          .neon-btn { animation: flicker 2s infinite alternate; }
          @keyframes flicker {
            0% { opacity: 1; }
            10% { opacity: 0.8; }
            20% { opacity: 1; }
            30% { opacity: 0.7; }
            40% { opacity: 1; }
            50% { opacity: 0.9; }
            60% { opacity: 1; }
            70% { opacity: 0.6; }
            80% { opacity: 1; }
            90% { opacity: 0.8; }
            100% { opacity: 1; }
          }
        `}</style>
      </form>
    </div>
  );
};

export default MemeForm;
