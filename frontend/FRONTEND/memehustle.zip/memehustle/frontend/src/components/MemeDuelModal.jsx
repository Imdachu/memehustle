import React, { useEffect, useState } from 'react';
import { useMemeContext } from '../context/MemeContext';

function MemeDuelModal({ open, onClose, isPageMode }) {
  const { memes, voteMeme } = useMemeContext();
  const [duelMemes, setDuelMemes] = useState([]);
  const [voted, setVoted] = useState(null);
  const [duelVotes, setDuelVotes] = useState([0, 0]);

  useEffect(() => {
    if (open && memes.length >= 2) {
      let idx1 = Math.floor(Math.random() * memes.length);
      let idx2;
      do { idx2 = Math.floor(Math.random() * memes.length); } while (idx2 === idx1);
      setDuelMemes([memes[idx1], memes[idx2]]);
      setVoted(null);
      setDuelVotes([0, 0]);
    }
  }, [open, memes]);

  if (!open || duelMemes.length < 2) return null;

  const handleVote = async (idx) => {
    await voteMeme(duelMemes[idx].id, 'up');
    setVoted(idx);
    setDuelVotes((prev) => {
      const newVotes = [...prev];
      newVotes[idx] += 1;
      return newVotes;
    });
  };

  const winnerIdx = duelVotes[0] > duelVotes[1] ? 0 : duelVotes[1] > duelVotes[0] ? 1 : null;

  // If isPageMode, render as a regular section, else as a modal overlay
  const Wrapper = isPageMode
    ? ({ children }) => <div className="w-full flex flex-col items-center justify-center">{children}</div>
    : ({ children }) => (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-95" style={{ fontFamily: 'Share Tech Mono, Fira Mono, monospace' }}>{children}</div>
    );

  return (
    <Wrapper>
      <div className="w-full max-w-3xl p-8 rounded-xl border-2 border-pink-600 shadow-cyber-glow bg-black bg-opacity-90 text-pink-400 flex flex-col items-center">
        <h2 className="text-3xl font-bold mb-6" style={{ textShadow: '0 0 8px #ff00cc' }}>Meme Duel</h2>
        <div className="flex flex-row gap-8 w-full justify-center">
          {duelMemes.map((meme, idx) => (
            <div key={meme.id} className={`flex-1 flex flex-col items-center p-4 rounded-xl border-2 ${voted === idx ? 'border-green-400' : 'border-blue-500'} bg-black bg-opacity-70 shadow-cyber-glow ${winnerIdx === idx ? 'animate-pulse-neon' : ''}`}>
              <img src={meme.image_url} alt={meme.title} className="w-48 h-48 object-cover rounded mb-2" style={{ boxShadow: '0 0 16px #00fff7' }} />
              <div className="font-bold text-lg mb-1" style={{ textShadow: '0 0 8px #ff00cc' }}>{meme.title}</div>
              <div className="text-xs text-cyan-400 mb-2">by {meme.uploaded_by}</div>
              <div className="mb-2 text-sm text-purple-400">{Array.isArray(meme.tags) ? meme.tags.join(', ') : meme.tags}</div>
              <div className="mb-2 text-green-400 font-mono text-xl">Votes: {duelVotes[idx]}</div>
              <button
                className={`px-4 py-2 mt-2 bg-pink-500 text-black rounded shadow-cyber-glow hover:bg-pink-700 transition-all duration-200 ${voted !== null ? 'opacity-50 cursor-not-allowed' : ''}`}
                disabled={voted !== null}
                onClick={() => handleVote(idx)}
              >
                {voted === idx ? 'Voted!' : 'Vote'}
              </button>
              {winnerIdx === idx && duelVotes[winnerIdx] > 0 && <div className="mt-2 text-green-400 font-bold animate-pulse">Duel Champion 🏆</div>}
            </div>
          ))}
        </div>
        {!isPageMode && (
          <button
            className="mt-8 px-6 py-2 bg-blue-500 text-black rounded shadow-cyber-glow hover:bg-blue-700 transition-all duration-200"
            onClick={onClose}
          >
            Close
          </button>
        )}
      </div>
      <style>{`
        .shadow-cyber-glow { box-shadow: 0 0 10px #ff00cc, 0 0 20px #00fff7; }
        @keyframes pulse-neon {
          0%, 100% { box-shadow: 0 0 16px #00fff7, 0 0 8px #ff00cc; }
          50% { box-shadow: 0 0 32px #00fff7, 0 0 24px #ff00cc; }
        }
        .animate-pulse-neon {
          animation: pulse-neon 1s infinite alternate;
        }
      `}</style>
    </Wrapper>
  );
}

export default MemeDuelModal; 