import { useState } from 'react';
import { useMemeContext } from '../context/MemeContext';

// Add glitch and flicker styles
const glitchStyle = {
  position: 'relative',
  color: '#ff00cc',
  fontFamily: '"Share Tech Mono", "Fira Mono", monospace',
  textShadow: '0 0 8px #ff00cc, 0 0 16px #00fff7, 0 0 2px #fff',
  animation: 'flicker 2s infinite alternate',
  fontSize: '1.3rem',
  letterSpacing: '1px',
  marginBottom: '0.5rem',
};

const MemeCard = ({ meme }) => {
  const [isVoting, setIsVoting] = useState(false);
  const [isBidding, setIsBidding] = useState(false);
  const [bidAmount, setBidAmount] = useState('');
  const { voteMeme, bidOnMeme, deleteMeme } = useMemeContext();
  const [imageError, setImageError] = useState(false);
  const fallbackImage = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgZmlsbD0iI2YwZjBmMCIvPjx0ZXh0IHg9IjUwJSIgeT0iNTAlIiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMjAiIGZpbGw9IiM2NjYiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGR5PSIuM2VtIj5JbWFnZSBub3QgZm91bmQ8L3RleHQ+PC9zdmc+';

  const handleVote = async (type) => {
    try {
      setIsVoting(true);
      await voteMeme(meme.id, type);
    } catch (error) {
      console.error('Vote error:', error);
    } finally {
      setIsVoting(false);
    }
  };

  const handleBid = async (e) => {
    e.preventDefault();
    if (!bidAmount || isNaN(bidAmount) || Number(bidAmount) <= 0) return;

    try {
      setIsBidding(true);
      await bidOnMeme(meme.id, {
        credits: Number(bidAmount),
        user_id: 'cyberpunk420' // TODO: Replace with actual user authentication
      });
      setBidAmount('');
    } catch (error) {
      console.error('Bid error:', error);
    } finally {
      setIsBidding(false);
    }
  };

  const handleImageError = () => {
    setImageError(true);
  };

  return (
    <div className="bg-black border-2 border-pink-500 rounded-lg overflow-hidden shadow-neon-pink hover:shadow-cyber-glitch transition-all duration-300 group" style={{ fontFamily: 'Share Tech Mono, Fira Mono, monospace' }}>
      <div className="relative">
        <img 
          src={imageError ? fallbackImage : meme.image_url} 
          alt={meme.caption || 'meme'} 
          className="w-full h-auto group-hover:scale-105 transition-transform duration-300"
          onError={handleImageError}
          style={{ boxShadow: '0 0 24px #00fff7, 0 0 8px #ff00cc' }}
        />
        <button
          onClick={() => deleteMeme(meme.id)}
          className="absolute top-2 right-2 px-2 py-1 bg-red-600 text-white rounded-full shadow-cyber-glow hover:bg-red-800 hover:scale-110 transition-all duration-200"
          title="Delete Meme"
          style={{ boxShadow: '0 0 10px #ff00cc, 0 0 20px #ff0000' }}
        >
          🗑️
        </button>
      </div>
      <div className="p-4">
        <div style={glitchStyle}>
          {meme.title || 'Untitled'}
        </div>
        <p className="font-bold text-pink-400 mb-1" style={{ textShadow: '0 0 8px #ff00cc, 0 0 16px #00fff7' }}>
          {meme.caption || 'No caption yet'}
        </p>
        <p className="text-xs text-cyan-400 mb-2" style={{ textShadow: '0 0 6px #00fff7' }}>by {meme.uploaded_by}</p>
        {Array.isArray(meme.tags) && meme.tags.length > 0 && (
          <div className="mb-2 text-xs text-purple-400" style={{ textShadow: '0 0 6px #a020f0' }}>
            Tags: {meme.tags.join(', ')}
          </div>
        )}
        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => handleVote('up')}
              disabled={isVoting}
              className="px-2 py-1 bg-pink-500 text-black rounded shadow-cyber-glow hover:bg-pink-700 hover:scale-110 transition-all duration-200 disabled:opacity-50"
              style={{ boxShadow: '0 0 10px #ff00cc, 0 0 20px #00fff7' }}
            >
              ↑
            </button>
            <span className="text-pink-400 text-lg font-mono" style={{ textShadow: '0 0 8px #ff00cc' }}>{meme.upvotes || 0}</span>
            <button
              onClick={() => handleVote('down')}
              disabled={isVoting}
              className="px-2 py-1 bg-pink-500 text-black rounded shadow-cyber-glow hover:bg-pink-700 hover:scale-110 transition-all duration-200 disabled:opacity-50"
              style={{ boxShadow: '0 0 10px #ff00cc, 0 0 20px #00fff7' }}
            >
              ↓
            </button>
          </div>
          <div className="text-sm text-blue-400 font-mono" style={{ textShadow: '0 0 8px #00fff7' }}>
            Highest bid: {meme.highestBid || 0} credits
          </div>
        </div>
        <form onSubmit={handleBid} className="mt-4 flex space-x-2">
          <input
            type="number"
            value={bidAmount}
            onChange={(e) => setBidAmount(e.target.value)}
            placeholder="Bid amount"
            className="flex-1 p-2 bg-black text-pink-400 border border-pink-500 rounded focus:ring-2 focus:ring-blue-500"
            disabled={isBidding}
            min="1"
            style={{ boxShadow: '0 0 8px #00fff7' }}
          />
          <button
            type="submit"
            disabled={isBidding || !bidAmount}
            className="px-4 py-2 bg-blue-500 text-black rounded shadow-cyber-glow hover:bg-blue-700 hover:scale-105 transition-all duration-200 disabled:opacity-50"
            style={{ boxShadow: '0 0 10px #00fff7, 0 0 20px #ff00cc' }}
          >
            {isBidding ? 'Bidding...' : 'Bid'}
          </button>
        </form>
      </div>
      {/* Glitch/flicker keyframes */}
      <style>{`
        @keyframes flicker {
          0% { opacity: 1; }
          10% { opacity: 0.8; }
          20% { opacity: 1; }
          30% { opacity: 0.7; }
          40% { opacity: 1; }
          50% { opacity: 0.9; }
          60% { opacity: 1; }
          70% { opacity: 0.6; }
          80% { opacity: 1; }
          90% { opacity: 0.8; }
          100% { opacity: 1; }
        }
        .shadow-neon-pink {
          box-shadow: 0 0 24px #ff00cc, 0 0 8px #00fff7;
        }
        .shadow-cyber-glow {
          box-shadow: 0 0 10px #ff00cc, 0 0 20px #00fff7;
        }
        .shadow-cyber-glitch {
          box-shadow: 0 0 32px #00fff7, 0 0 16px #ff00cc, 0 0 8px #a020f0;
        }
      `}</style>
    </div>
  );
};

export default MemeCard;
