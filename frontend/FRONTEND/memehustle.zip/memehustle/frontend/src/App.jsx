import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import { MemeProvider } from './context/MemeContext';
import Home from './pages/Home';
import CreateMeme from './pages/CreateMeme';
import Leaderboard from './pages/Leaderboard';
import MemeDuel from './pages/MemeDuel';

function App() {
  return (
    <MemeProvider>
      {/* Animated cyberpunk background - always covers the viewport */}
      <div className="fixed inset-0 w-full h-full -z-10 animate-gradient bg-gradient-to-br from-black via-blue-950 to-fuchsia-900 opacity-90" />
      <div className="min-h-screen w-full font-mono" style={{ fontFamily: 'Share Tech Mono, Fira Mono, monospace' }}>
        <BrowserRouter>
          {/* Neon Navbar - full width, background covers entire bar */}
          <nav className="sticky top-0 z-30 w-full bg-black bg-opacity-90 border-b-2 border-pink-600 shadow-cyber-glitch px-8 py-4">
            <div className="flex flex-row justify-center gap-10 w-full">
              <Link to="/" className="text-pink-400 text-lg font-mono hover:text-pink-300 transition-all">Home</Link>
              <Link to="/create" className="text-green-400 text-lg font-mono hover:text-green-300 transition-all">Create Meme</Link>
              <Link to="/leaderboard" className="text-yellow-300 text-lg font-mono hover:text-yellow-200 transition-all">Leaderboard</Link>
              <Link to="/duel" className="text-cyan-400 text-lg font-mono hover:text-cyan-300 transition-all">Meme Duel</Link>
            </div>
          </nav>
          {/* Main Content */}
          <main className="flex-1 flex flex-col items-center justify-center px-4 py-12 min-h-[calc(100vh-96px)] w-full">
            <div className="w-full max-w-none flex flex-col items-center justify-center px-4">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/create" element={<CreateMeme />} />
                <Route path="/leaderboard" element={<Leaderboard />} />
                <Route path="/duel" element={<MemeDuel />} />
              </Routes>
            </div>
          </main>
          <footer className="w-full text-center py-4 text-xs text-pink-400 bg-black bg-opacity-70 border-t border-pink-700" style={{ letterSpacing: '1px' }}>
            &copy; {new Date().getFullYear()} MemeHustle — Built with 💜 in Cyberpunk Mode
          </footer>
          <style>{`
            .shadow-cyber-glitch { box-shadow: 0 0 32px #00fff7, 0 0 16px #ff00cc, 0 0 8px #a020f0; }
            .animate-gradient {
              background-size: 400% 400%;
              animation: gradientBG 16s ease-in-out infinite;
            }
            @keyframes gradientBG {
              0%, 100% { background-position: 0% 50%; }
              50% { background-position: 100% 50%; }
            }
          `}</style>
        </BrowserRouter>
      </div>
    </MemeProvider>
  );
}

export default App;
