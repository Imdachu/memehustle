import { GoogleGenerativeAI } from "@google/generative-ai";
import dotenv from 'dotenv';

dotenv.config();

// Validate environment variables
if (!process.env.GEMINI_API_KEY) {
  throw new Error('Missing Gemini API key. Please check your .env file.');
}

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// Initialize the model
const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });

// Validate image URL
const isValidImageUrl = (url) => {
  try {
    new URL(url);
    return url.match(/\.(jpeg|jpg|gif|png)$/) != null;
  } catch {
    return false;
  }
};

// Retry mechanism
const retry = async (fn, retries = 3, delay = 1000) => {
  try {
    return await fn();
  } catch (error) {
    if (retries === 0) throw error;
    await new Promise(resolve => setTimeout(resolve, delay));
    return retry(fn, retries - 1, delay);
  }
};

const captionService = {
  generateCaption: async (imageUrl) => {
    try {
      // Validate image URL
      if (!isValidImageUrl(imageUrl)) {
        throw new Error('Invalid image URL. Must be a valid URL ending with .jpeg, .jpg, .gif, or .png');
      }

      // Test API key
      try {
        await model.generateContent(["Test connection"]);
      } catch (error) {
        throw new Error('Invalid Gemini API key or API access error');
      }

      // Generate caption with retry mechanism
      return await retry(async () => {
        const result = await model.generateContent([
          "Generate a funny meme caption for the image:",
          { image: { url: imageUrl }, mimeType: "image/png" },
        ]);
        return result.response.text();
      });
    } catch (err) {
      console.error('❌ Gemini error:', err);
      // Return a default caption if generation fails
      return "YOLO to the moon! 🚀";
    }
  },

  // Add a method to test the API connection
  testConnection: async () => {
    try {
      // Test with a simple prompt
      const result = await model.generateContent('Hello, are you working?');
      const response = await result.response;
      return response.text() === 'Hello, are you working?';
    } catch (error) {
      console.error('❌ Gemini API test failed:', error);
      throw error;
    }
  }
};

export default captionService;