import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

// Validate environment variables
if (!process.env.SUPABASE_URL || !process.env.SUPABASE_KEY) {
  throw new Error('Missing Supabase credentials. Please check your .env file.');
}

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

// Test database connection
const testConnection = async () => {
  try {
    const { error } = await supabase.from('memes').select('count').limit(1);
    if (error) throw error;
    console.log('✅ Successfully connected to Supabase');
  } catch (error) {
    console.error('❌ Failed to connect to Supabase:', error);
    throw error;
  }
};

const supabaseService = {
  testConnection,

  getAllMemes: async () => {
    try {
      const { data, error } = await supabase
        .from('memes')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('❌ Error fetching memes:', error);
      throw error;
    }
  },

  insertMeme: async (imageUrl, uploadedBy, caption) => {
    try {
      if (!imageUrl || !uploadedBy) {
        throw new Error('Missing required fields: imageUrl and uploadedBy are required');
      }

      const { data, error } = await supabase
        .from('memes')
        .insert([{ 
          image_url: imageUrl, 
          uploaded_by: uploadedBy, 
          caption,
          upvotes: 0,
          created_at: new Date().toISOString()
        }])
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('❌ Error inserting meme:', error);
      throw error;
    }
  },

  voteMeme: async (id, type) => {
    try {
      if (!['up', 'down'].includes(type)) {
        throw new Error('Invalid vote type. Must be "up" or "down"');
      }

      // First get the current upvotes
      const { data: currentMeme, error: fetchError } = await supabase
        .from('memes')
        .select('upvotes')
        .eq('id', id)
        .single();

      if (fetchError) throw fetchError;

      const increment = type === 'up' ? 1 : -1;
      const newUpvotes = (currentMeme.upvotes || 0) + increment;

      // Update with the new upvotes count
      const { data, error } = await supabase
        .from('memes')
        .update({ upvotes: newUpvotes })
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('❌ Error voting on meme:', error);
      throw error;
    }
  },

  placeBid: async (memeId, userId, amount) => {
    try {
      if (!memeId || !userId || !amount) {
        throw new Error('Missing required fields for bid');
      }

      // Check current highest bid
      const { data: currentMeme, error: fetchError } = await supabase
        .from('memes')
        .select('highest_bid, highest_bidder')
        .eq('id', memeId)
        .single();

      if (fetchError) throw fetchError;

      if (currentMeme.highest_bid && amount <= currentMeme.highest_bid) {
        throw new Error('Bid must be higher than current highest bid');
      }

      // Place new bid
      const { data, error } = await supabase
        .from('memes')
        .update({ 
          highest_bid: amount,
          highest_bidder: userId,
          updated_at: new Date().toISOString()
        })
        .eq('id', memeId)
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('❌ Error placing bid:', error);
      throw error;
    }
  },

  getLeaderboard: async (limit = 10) => {
    try {
      const { data, error } = await supabase
        .from('memes')
        .select('*')
        .order('upvotes', { ascending: false })
        .limit(limit);

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('❌ Error fetching leaderboard:', error);
      throw error;
    }
  }
};

export default supabaseService;
