import supabaseService from '../services/supabaseService.js';
import captionService from '../services/captionService.js';

export const getAllMemes = async (req, res) => {
  const memes = await supabaseService.getAllMemes();
  return res.json(memes);
};

export const createMeme = async (req, res) => {
  const { imageUrl, uploadedBy } = req.body;
  try {
    const caption = await captionService.generateCaption(imageUrl);
    const newMeme = await supabaseService.insertMeme(imageUrl, uploadedBy, caption);
    return res.status(201).json(newMeme);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
};

export const voteMeme = async (req, res) => {
  try {
    const { type } = req.body;
    if (!['up', 'down'].includes(type)) {
      return res.status(400).json({ error: 'Invalid vote type' });
    }

    const { data, error } = await supabaseService.voteMeme(req.params.id, type);

    if (error) throw error;

    res.json(data);
  } catch (error) {
    console.error('Vote error:', error);
    res.status(500).json({ error: 'Failed to process vote' });
  }
};