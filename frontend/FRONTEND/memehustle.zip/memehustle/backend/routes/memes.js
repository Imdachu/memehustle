import express from 'express';
import { supabase } from '../lib/supabase.js';
import { genCaption, genVibe } from '../lib/gemini.js';
import { io } from '../index.js';
import { validateMeme, validateVote, validateBid } from '../middleware/validation.js';
import supabaseService from '../services/supabaseService.js';

const router = express.Router();

// Create a new meme
router.post('/', validateMeme, async (req, res, next) => {
  try {
    let { image_url, uploaded_by, title, tags } = req.body;
    console.log('📝 Creating new meme:', { image_url, uploaded_by, title, tags });

    // Normalize tags: if string, split by comma; if array, use as is; else empty array
    if (typeof tags === 'string') {
      tags = tags.split(',').map(t => t.trim()).filter(Boolean);
    } else if (!Array.isArray(tags)) {
      tags = [];
    }

    // Insert meme with no caption/vibe
    const { data: meme, error } = await supabase
      .from('memes')
      .insert([{ 
        image_url, 
        uploaded_by,
        title,
        tags,
        upvotes: 0,
        created_at: new Date().toISOString()
      }])
      .select()
      .single();

    if (error) {
      console.error('❌ Error inserting meme:', error);
      throw error;
    }

    // Generate caption and vibe automatically
    let updatedMeme = meme;
    try {
      console.log('✨ Generating caption and vibe for meme:', meme.id);
      const [caption, vibe] = await Promise.all([
        genCaption(tags.length ? tags : [title]),
        genVibe(tags.length ? tags : [title])
      ]);
      console.log('✅ Caption generated:', caption);
      console.log('✅ Vibe generated:', vibe);
      // Update meme with caption and vibe
      const { data: memeWithCaption, error: updateError } = await supabase
        .from('memes')
        .update({ caption, vibe })
        .eq('id', meme.id)
        .select()
        .single();
      if (updateError) {
        console.error('❌ Error updating meme with caption/vibe:', updateError);
      } else {
        updatedMeme = memeWithCaption;
        console.log('✅ Meme updated with caption and vibe:', updatedMeme);
      }
    } catch (captionError) {
      console.error('❌ Error generating caption/vibe:', captionError);
      // Proceed with original meme if caption fails
    }

    io.emit('new-meme', updatedMeme);
    res.status(201).json(updatedMeme);
  } catch (error) {
    next(error);
  }
});

// Get all memes
router.get('/', async (req, res, next) => {
  try {
    console.log('🔍 Fetching all memes...');
    const { data, error } = await supabase
      .from('memes')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('❌ Supabase error:', error);
      throw error;
    }

    console.log(`✅ Successfully fetched ${data.length} memes`);
    res.json(data);
  } catch (error) {
    console.error('❌ Error in GET /memes:', error);
    next(error);
  }
});

// Vote on a meme
router.post('/:id/vote', validateVote, async (req, res, next) => {
  try {
    const { type } = req.body;
    const data = await supabaseService.voteMeme(req.params.id, type);
    
    io.emit('vote', { id: req.params.id, upvotes: data.upvotes });
    res.json(data);
  } catch (error) {
    next(error);
  }
});

// Place a bid on a meme
router.post('/:id/bid', validateBid, async (req, res, next) => {
  try {
    const { credits, user_id } = req.body;

    // Start a transaction
    const { data: meme, error: memeError } = await supabase
      .from('memes')
      .select('highest_bid')
      .eq('id', req.params.id)
      .single();

    if (memeError) throw memeError;

    if (meme.highest_bid && credits <= meme.highest_bid) {
      return res.status(400).json({
        error: 'Invalid Bid',
        details: 'Bid must be higher than current highest bid'
      });
    }

    const { data, error } = await supabase
      .from('bids')
      .insert([{ 
        meme_id: req.params.id, 
        user_id, 
        credits,
        created_at: new Date().toISOString()
      }])
      .select()
      .single();

    if (error) throw error;

    io.emit('bid', { 
      id: req.params.id, 
      user_id, 
      credits,
      timestamp: new Date().toISOString()
    });

    res.status(201).json(data);
  } catch (error) {
    next(error);
  }
});

// Generate caption for a meme
router.post('/:id/caption', async (req, res, next) => {
  try {
    const { data: meme, error: memeError } = await supabase
      .from('memes')
      .select('*')
      .eq('id', req.params.id)
      .single();

    if (memeError) throw memeError;

    const [caption, vibe] = await Promise.all([
      genCaption(meme.tags || []),
      genVibe(meme.tags || [])
    ]);

    const { data, error } = await supabase
      .from('memes')
      .update({ caption, vibe })
      .eq('id', req.params.id)
      .select()
      .single();

    if (error) throw error;

    io.emit('caption', data);
    res.json(data);
  } catch (error) {
    next(error);
  }
});

// Get leaderboard
router.get('/leaderboard', async (req, res, next) => {
  try {
    const top = parseInt(req.query.top) || 10;
    const { data, error } = await supabase
      .from('memes')
      .select('*')
      .order('upvotes', { ascending: false })
      .limit(top);

    if (error) throw error;
    res.json(data);
  } catch (error) {
    next(error);
  }
});

// Delete a meme
router.delete('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const { error } = await supabase
      .from('memes')
      .delete()
      .eq('id', id);

    if (error) throw error;

    // Emit a socket event to update all clients
    io.emit('delete-meme', { id });

    res.status(204).send();
  } catch (error) {
    next(error);
  }
});

export default router;
