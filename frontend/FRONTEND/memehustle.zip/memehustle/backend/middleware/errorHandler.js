export const errorHandler = (err, req, res, next) => {
  console.error('❌ Error details:', {
    message: err.message,
    code: err.code,
    name: err.name,
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
  });

  // Supabase specific errors
  if (err.code === '42P01') {
    return res.status(500).json({
      error: 'Database Error',
      details: 'The memes table does not exist. Please run the database setup script.',
      code: err.code
    });
  }

  if (err.code === '23505') {
    return res.status(409).json({
      error: 'Duplicate Entry',
      details: err.message,
      code: err.code
    });
  }

  if (err.name === 'ValidationError') {
    return res.status(400).json({
      error: 'Validation Error',
      details: err.message
    });
  }

  if (err.name === 'UnauthorizedError') {
    return res.status(401).json({
      error: 'Unauthorized',
      details: 'Please log in to continue'
    });
  }

  if (err.name === 'ForbiddenError') {
    return res.status(403).json({
      error: 'Forbidden',
      details: 'You do not have permission to perform this action'
    });
  }

  // Default error
  res.status(500).json({
    error: 'Internal Server Error',
    details: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong',
    code: err.code || 'UNKNOWN_ERROR'
  });
}; 