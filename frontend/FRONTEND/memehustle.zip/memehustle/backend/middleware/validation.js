export const validateMeme = (req, res, next) => {
  const { image_url, uploaded_by, title, tags } = req.body;

  if (!image_url) {
    return res.status(400).json({
      error: 'Validation Error',
      details: 'Image URL is required'
    });
  }

  try {
    new URL(image_url);
  } catch {
    return res.status(400).json({
      error: 'Validation Error',
      details: 'Invalid image URL format'
    });
  }

  if (!uploaded_by) {
    return res.status(400).json({
      error: 'Validation Error',
      details: 'Uploader information is required'
    });
  }

  if (!title || typeof title !== 'string' || !title.trim()) {
    return res.status(400).json({
      error: 'Validation Error',
      details: 'Title is required'
    });
  }

  // tags is optional, but if present, should be an array or comma-separated string
  if (tags && !Array.isArray(tags) && typeof tags !== 'string') {
    return res.status(400).json({
      error: 'Validation Error',
      details: 'Tags must be an array or a comma-separated string'
    });
  }

  next();
};

export const validateVote = (req, res, next) => {
  const { type } = req.body;

  if (!type || !['up', 'down'].includes(type)) {
    return res.status(400).json({
      error: 'Validation Error',
      details: 'Vote type must be either "up" or "down"'
    });
  }

  next();
};

export const validateBid = (req, res, next) => {
  const { credits, user_id } = req.body;

  if (!credits || isNaN(credits) || Number(credits) <= 0) {
    return res.status(400).json({
      error: 'Validation Error',
      details: 'Bid amount must be a positive number'
    });
  }

  if (!user_id) {
    return res.status(400).json({
      error: 'Validation Error',
      details: 'User ID is required'
    });
  }

  next();
}; 