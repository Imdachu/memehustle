import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Initialize Supabase client
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_KEY
);

async function setupDatabase() {
  try {
    console.log('🔧 Verifying database setup...');
    
    // Check if table exists
    const { error } = await supabase
      .from('memes')
      .select('count')
      .limit(1);

    if (error) {
      if (error.code === '42P01') {
        console.error('❌ The memes table does not exist. Please run the SQL script in the Supabase SQL Editor.');
        process.exit(1);
      } else {
        console.error('❌ Error checking table:', error);
        process.exit(1);
      }
    }

    console.log('✅ Database setup verified successfully!');
  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  }
}

setupDatabase(); 