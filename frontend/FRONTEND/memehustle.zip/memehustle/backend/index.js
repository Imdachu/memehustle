import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import dotenv from 'dotenv';
import memesRouter from './routes/memes.js';
import { errorHandler } from './middleware/errorHandler.js';
import supabaseService from './services/supabaseService.js';
import captionService from './services/captionService.js';

// Load environment variables
console.log('🔧 Loading environment variables...');
dotenv.config();
console.log('✅ Environment variables loaded');

const app = express();
const server = http.createServer(app);

// Configure CORS
console.log('🔒 Configuring CORS...');
const allowedOrigins = process.env.ALLOWED_ORIGINS 
  ? process.env.ALLOWED_ORIGINS.split(',') 
  : ['http://localhost:3000', 'http://localhost:3001', 'http://localhost:5173'];
console.log('🌐 Allowed origins:', allowedOrigins);

export const io = new Server(server, {
  cors: {
    origin: (origin, callback) => {
      console.log('🔍 Checking CORS for origin:', origin);
      if (!origin || allowedOrigins.includes(origin)) {
        console.log('✅ CORS allowed for origin:', origin);
        callback(null, true);
      } else {
        console.log('❌ CORS denied for origin:', origin);
        callback(new Error('Not allowed by CORS'));
      }
    },
    methods: ['GET', 'POST'],
    credentials: true
  }
});

// Middleware
console.log('⚙️ Setting up middleware...');
app.use(express.json());
app.use(cors({
  origin: (origin, callback) => {
    console.log('🔍 Checking CORS middleware for origin:', origin);
    if (!origin || allowedOrigins.includes(origin)) {
      console.log('✅ CORS middleware allowed for origin:', origin);
      callback(null, true);
    } else {
      console.log('❌ CORS middleware denied for origin:', origin);
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true
}));
console.log('✅ Middleware setup complete');

// Routes
console.log('🛣️ Setting up routes...');
app.use('/memes', memesRouter);
console.log('✅ Routes setup complete');

// Socket.io connection handling
io.on('connection', (socket) => {
  console.log('⚡ New user connected:', socket.id);
  console.log('📊 Active connections:', io.engine.clientsCount);

  socket.on('disconnect', () => {
    console.log('👋 User disconnected:', socket.id);
    console.log('📊 Remaining connections:', io.engine.clientsCount);
  });

  socket.on('error', (error) => {
    console.error('❌ Socket error for user', socket.id, ':', error);
  });
});

// Error handling
console.log('⚠️ Setting up error handling...');
app.use(errorHandler);
console.log('✅ Error handling setup complete');

// Start server
const PORT = process.env.PORT || 3000;
const MAX_PORT_ATTEMPTS = 5;

const startServer = async () => {
  console.log('🚀 Starting server...');
  
  try {
    // Test database connection
    console.log('🔍 Testing database connection...');
    await supabaseService.testConnection();
    
    // Test Gemini API connection
    console.log('🔍 Testing Gemini API connection...');
    await captionService.testConnection();
    
    let currentPort = PORT;
    let attempts = 0;

    const tryStartServer = () => {
      try {
        server.listen(currentPort, () => {
          console.log(`✅ Server successfully running on port ${currentPort}`);
          console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
          console.log('📝 Server configuration:');
          console.log('- CORS enabled:', true);
          console.log('- JSON parsing enabled:', true);
          console.log('- Socket.IO enabled:', true);
          console.log('- Database connected:', true);
          console.log('- Gemini API connected:', true);
        });

        server.on('error', (error) => {
          if (error.code === 'EADDRINUSE') {
            attempts++;
            if (attempts >= MAX_PORT_ATTEMPTS) {
              console.error('❌ Could not find an available port after multiple attempts');
              process.exit(1);
            }
            console.log(`⚠️ Port ${currentPort} is already in use. Trying port ${currentPort + 1}...`);
            currentPort++;
            server.close();
            tryStartServer();
          } else {
            console.error('❌ Fatal server error:', error);
            process.exit(1);
          }
        });
      } catch (error) {
        console.error('❌ Failed to start server:', error);
        process.exit(1);
      }
    };

    tryStartServer();
  } catch (error) {
    console.error('❌ Startup checks failed:', error);
    process.exit(1);
  }
};

startServer();
